---
name: workstation-workflow-review
description: Use when auditing or improving a developer workstation, Codex workflow, agent control plane, skills, hooks, MCP setup, toolchain, automations, or recurring manual workflows. Turns evidence-based review into bounded improvement slices with explicit risk gates, validation, rollback notes, and asset creation decisions.
---

# Workstation Workflow Review

Use this skill to inspect a workstation or Codex operating workflow, identify repeated manual work, and convert only well-supported findings into small, verifiable improvements.

This skill is for design, audit, hardening, and controlled improvement. It is not completion authority: direct files, command output, tests, runtime state, and user instructions outrank old summaries or memory.

## Workflow

1. Bind the request.
   - State target, allowed write surface, excluded surfaces, success threshold, and final output shape.
   - If the task touches active runtime, hooks, MCP, PATH, tool installs, secrets, external publishing, deletion, migration, or automation schedules, treat it as high risk unless the user explicitly opened that boundary.

2. Collect read-only evidence first.
   - Inspect only the needed source files, configs, docs, command outputs, summaries, registries, and logs.
   - Do not read raw secrets or credential material unless the user named the exact file and requested that boundary.
   - Record what was inspected, what was not inspected, and which sensitive boundaries stayed closed.

3. Classify surfaces.
   - Review surfaces: `developer-environment`, `toolchain`, `agent-control-plane`, `project-codebase`, `runtime-state`, `security-boundary`, `product-ops`.
   - Change surfaces: `managed-source`, `active-runtime`, `toolchain`, `security-boundary`, `runtime-state`, `project-codebase`, `product-ops`.
   - Risk levels: `observe`, `draft`, `controlled-change`, `high-risk-change`.

4. Review from evidence.
   - Separate facts, hypotheses, preferences, and unchecked claims.
   - For each important finding include failure surface, why it matters, evidence, affected scope, first action, confidence, and verification path.
   - Score broad audits only when evidence supports it: Developer Experience, Architecture and Design, Performance and Reliability, Security Posture, Ecosystem Maturity, Agent Experience, Technical and Codebase Health, Product and Operational Impact.
   - Use one verdict: `strategic_asset`, `conditional_asset`, `operational_liability`, or `replace_now`.

5. Normalize findings.
   - `P0`: secret exposure, destructive-action risk, data loss, false success, completion-authority collapse.
   - `P1`: reliability blocker, reproducibility failure, state drift, runtime coupling, rollback gap, CI or test gap.
   - `P2`: developer or agent productivity drag, onboarding friction, documentation drift, command ergonomics, local assumptions.
   - `P3`: naming, reporting clarity, policy simplification, convenience.
   - Confidence: `verified`, `likely`, `plausible`, `unverified`.

6. Find workflow assets conservatively.
   - Candidate assets require at least two occurrences, or high recurrence probability with high repeat cost.
   - Inputs, procedure, outputs, and stop condition must be stable.
   - Check existing skills, agents, automations, and runbooks before creating a new asset.
   - Choose the smallest fitting form: `Skill`, `Custom subagent`, `Automation`, `Extend existing`, or `Skip`.
   - Skip vague, one-off, sensitive, duplicate, or weak-evidence candidates.

7. Harden into one bounded goal.
   - Define a `GOAL_SPEC` with problem statement, evidence, included and excluded scope, priority order, acceptance criteria, stop condition, rollback or safe-stop, and first direct verification.
   - Select one slice. Prefer low-risk managed-source or draft changes before active runtime or security changes.

8. Execute and verify.
   - Mutate the smallest live surface that satisfies the selected slice.
   - Verify the final artifact or effective state through the same interface that will consume it.
   - Record checks run, checks not run, direct evidence, rollback notes, residual risk, and next slice.

## High-Risk Gates

Do not mutate these without explicit current user intent for that boundary:

- shell profile, PATH, version manager, wrapper, shim, or global install route
- active MCP server registration, hook enablement, trust settings, or automation schedule
- raw secrets, credential rotation, token scopes, deploy or publish permission
- destructive filesystem action, data migration, log movement, SQLite WAL/SHM deletion
- browser or native host state changes outside the requested target

If high-risk work is requested, keep it narrow, prefer dry-run or readback first, and include rollback or safe-stop instructions in the slice report.

## Output Contract

For an audit or design task, return:

```markdown
## EVIDENCE_LEDGER
### Inspected
| Source | Path/System | Evidence type | Notes |
|---|---|---|---|

### Not inspected
| Source | Reason | Risk created |
|---|---|---|

### Sensitive boundaries not opened
| Boundary | Reason | Required authorization if needed |
|---|---|---|

## SURFACE_MAP
| Surface | Classification | Risk | Evidence |
|---|---|---|---|

## FINDING_MAP
| ID | Priority | Finding | Confidence | Evidence | First action |
|---|---|---|---|---|---|

## WORKFLOW_SHORTLIST
| Candidate | Form | Evidence | Decision | Reason |
|---|---|---|---|---|

## GOAL_SPEC
- Problem:
- Evidence:
- Included scope:
- Excluded scope:
- Acceptance criteria:
- Stop condition:
- Rollback / safe-stop:

## SLICE_REPORT
- Selected slice:
- Work performed:
- Checks run:
- Checks not run:
- Direct evidence:
- Residual risks:
- Next slice:
```

For implementation work, include the changed surfaces, current proof, not-run checks, rollback notes, and whether any created or extended asset was validated.

## Reference

Read `references/workstation-workflow-full-review.md` when the task needs the full source plan, detailed templates, score rubric, workstation audit checklist, operating rhythm, or diagrams.
